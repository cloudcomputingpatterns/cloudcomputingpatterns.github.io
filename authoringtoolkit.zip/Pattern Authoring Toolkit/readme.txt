Pattern Authoring Toolkit v. 1.0

1. Pattern_Template.doc:
Word template for the proposed pattern format with placeholders for the icon and sketch figures.

2. Capturing_Information_Sources.xls:
Excel template for the organization of information sources from which patterns are abstracted. 
- 1st sheet: exemplary sources and abstractions.
- 2nd Sheet: empty sheet for capturing new sources.
- 3rd sheet: list of architectural domains and challenges (extendable) forming the basis for drop-down menus of the first two sheets.

3. Icon_and_Sketch_Template.ppt:
PowerPoint template with exemplary shapes to use in new pattern icons and sketches.
